import random
import numpy as np
import scipy.stats as stats


def divide_into_12(n):
    random.seed(n)  # Ensure the same output for the same input

    while True:
        # Generate 12 unique numbers in range [-10,10]
        numbers = random.sample(range(-10, 11), 12)

        # Adjust the sum to match 'n'
        diff = sum(numbers) - n
        if diff == 0:
            return numbers  # Found valid numbers

        # Try to adjust one number to fix the sum
        for i in range(12):
            new_value = numbers[i] - diff
            if -10 <= new_value <= 10 and new_value not in numbers:
                numbers[i] = new_value
                return numbers  # Successfully adjusted


class sampler:
    def __init__(self, id):
        self.id = id
        self.means = divide_into_12(id % 10)
        self.stds = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
        if len(self.means) != 12 or len(self.stds) != 12:
            raise ValueError("Both means and std_devs must have exactly 12 elements.")

        self.distributions = [
            stats.norm(mean, std_dev) for mean, std_dev in zip(self.means, self.stds)
        ]

    def sample(self, i):
        """Sample a value from the i-th Gaussian distribution (0-based index)."""
        if not (0 <= i < 12):
            raise ValueError("Index i must be between 0 and 11.")

        return self.distributions[i].rvs()
